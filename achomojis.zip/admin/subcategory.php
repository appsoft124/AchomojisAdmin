<?php
require_once "header.php";

// Fetch all categories (assuming you need categories for the subcategory listing)
$categories = $db->run('SELECT * from categories ORDER BY name ASC');

// Get the current category from GET request, default to the first category if not set
if (isset($_GET['category'])) {
  $category_id = $_GET['category'];
} else {
  $category_id = $categories[0]['id']; // Default category
}

//   $subcategories = $db->run('SELECT * FROM subcategories'); // Fetch all subcategories
  $subcategories = $db->run('SELECT * FROM subcategories ORDER BY name ASC');
  
//   $subcategories = $db->run('SELECT * FROM subcategories ORDER BY name COLLATE utf8_general_ci ASC');




?>

<div class="loader text-center" id="loader">
  <!-- <img src="images/loading.gif" style="width:30%; margin-top:100px"> -->
</div>

<section class="content-main">
  <div class="content-header">
    <div>
      <h2 class="content-title">Subcategories</h2>
    </div>

    <div>
      <!--<a class="btn text-white btn-success btn-sm" style="padding: 0px !important; margin-top:2px !important">
        <select name="category" id="category" class="outline-none border-none btn px-3 py-2" style="font-size: 16px; width: 200px; height: 40px;">
          <?php
          foreach ($categories as $category) {
            $selected = ($category_id == $category['id']) ? 'selected' : '';
            echo '<option value="' . $category['id'] . '" ' . $selected . '>' . $category['name'] . '</option>';
          }
          ?>
        </select>
      </a>-->

      <a class="btn text-white btn-success btn-sm" href="add_subcategory.php">Add Subcategory</a>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover" id="myTableSurface">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php foreach ($subcategories as $subcategory) {
              // Get the category name
              $category = $db->row('SELECT * FROM categories WHERE id = ?', $subcategory['category_id']);
            ?>
              <tr class="subcategory" id="<?= $subcategory['id']; ?>">
                <td><?php echo $subcategory['id']; ?></td>
             

              <td>
               <img src="<?= (is_full_url($subcategory['image_url']) ? $subcategory['image_url'] : $tbase . $subcategory['image_url']) ?>" style="height:80px; width:100px; object-fit: cover;">
                </td>

                <td><?php echo $subcategory['name']; ?></td>
                <td><?php echo $category['name']; ?></td>
                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light">
                      <span class="material-symbols-rounded">more_horiz</span>
                    </a>
                    <div class="dropdown-menu">
                  
                      <button class="dropdown-item text-primary edit" data-type="subcategory" data-id="<?= $subcategory['id']; ?>">Edit</button>
                      <button class="dropdown-item text-danger delete" data-type="subcategory" data-id="<?= $subcategory['id']; ?>">Delete</button>
                    </div>
                  </div>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</section>

<?php
require_once "footer.php";
?>

<script>
  $(document).ready(function () {

    $("#loader").css("display", "none");

    // Handle category change event
    $('#category').change(function () {
      var category_id = $('#category').val();
      location.replace('./subcategory.php?category=' + category_id);
    });

    // Initialize DataTable for the subcategory table
    $('#myTableSurface').DataTable({
      "pageLength": 50,
      "ordering": false 
      
    });

  });
</script>
