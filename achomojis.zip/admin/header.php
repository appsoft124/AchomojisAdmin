<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: index.php");
  exit;
}
include "../core/db.php";
$settings = $db->row('SELECT * from settings limit 1');
$tbase = $settings['tbase'];
?>
<!DOCTYPE HTML>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin Dashboard</title>

  <link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="css/bootstrapf9e3.css?v=1.1" rel="stylesheet" type="text/css" />
  <link href="css/uif9e3.css?v=1.1" rel="stylesheet" type="text/css" />
  <link href="css/responsivef9e3.css?v=1.1" rel="stylesheet" />
  <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" data-auto-replace-svg></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,1,0" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css" />

  <style>
    .row div { margin-bottom: 15px; }
    hr { margin-top: 50px !important; margin-bottom: 50px !important; }
    .card { margin-bottom: 100px !important; }
    .navbar-aside.dark { color: white; }
  </style>
</head>

<body>

<b class="screen-overlay"></b>

<aside class="navbar-aside" id="offcanvas_aside" style="background-color: none;">
  <div class="aside-top">
    <a href="languages.php" class="brand-wrap menu-link" style="text-decoration:none !important; color:gray">
      Languages
    </a>
    <div>
      <button class="btn btn-icon btn-aside-minimize">
        <span class="material-symbols-rounded">keyboard_double_arrow_left</span>
      </button>
    </div>
  </div>

  <nav>
    <ul class="menu-aside">

      <li class="menu-item">
        <a class="menu-link" href="category.php">
          <i class="fas fa-list-alt me-2"></i>
          <span class="text">Category</span>
        </a>
      </li>

      <li class="menu-item">
        <a class="menu-link" href="subcategory.php">
          <i class="fas fa-stream me-2"></i>
          <span class="text">Sub Category</span>
        </a>
      </li>

      <li>
        <a class="menu-link" href="paid_emojis.php">
          <i class="fas fa-smile me-2"></i>
          <span class="text">Paid Emojis</span>
        </a>
      </li>
      
      
      <li>
        <a class="menu-link" href="free_emojis.php">
          <i class="fas fa-smile me-2"></i>
          <span class="text">Free Emojis</span>
        </a>
      </li>

      <li>
        <a class="menu-link" href="notifications.php">
          <i class="fas fa-bell me-2"></i>
          <span class="text">Notifications</span>
        </a>
      </li>

      <hr>

      <li class="menu-item">
        <a class="menu-link" href="more_apps.php">
          <i class="fas fa-th-list me-2"></i>
          <span class="text">More Apps</span>
        </a>
      </li>

      

      <li class="menu-item">
        <a class="menu-link" href="admins.php">
          <i class="fas fa-user-shield me-2"></i>
          <span class="text">Admins</span>
        </a>
      </li>

  

    </ul>
  </nav>
</aside>

<main class="main-wrap">
  <header class="main-header navbar">
    <div class="col-search"></div>
    <div class="col-nav">
      <button class="btn btn-icon btn-mobile me-auto" data-trigger="#offcanvas_aside">
        <span class="material-symbols-rounded">menu</span>
      </button>
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link btn-icon" onclick="darkmode(this)" title="Dark mode" href="#">
            <span class="material-symbols-rounded">dark_mode</span>
          </a>
        </li>
        <li class="dropdown nav-item">
          <a class="dropdown-toggle" data-bs-toggle="dropdown" href="#">
            <img class="img-xs rounded-circle" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFJWaTeWH7LxZfrb4qdMAvf5v5lNDIGs14pVH68NBFQJI1mUpbwAMcJigKRPcgk_NQQxBcLdtL8dtgLmLZqwJ2VKzyPkiGehZPWhK3Iw5POdGdF924E83A2yLzI3hU7LHYfmrLNPwmRmbdXz7-b9L0f5e_iFz-Dupc978ljqfhwGOPaetNYMPnUeaw4A/s6160/1682070856867.jpg" alt="User">
          </a>
          <div class="dropdown-menu dropdown-menu-end">
            <a class="dropdown-item text-danger" href="core/actions.php?signout=1">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </header>