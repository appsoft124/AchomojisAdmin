<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

$id = $_REQUEST['id'];

if (isset($id)) {
    $movie = $db->row('SELECT * FROM more_apps WHERE id = ?', $id);
    $name = $movie['name'];
    $thumb = $movie['thumb'];
    $link = $movie['link'];
}


?>


<section class="content-main" style="max-width: 70%">

    <div class="content-header">
        <h2 class="content-title"><?php if (isset($id)) echo 'Update';
                                    else echo 'Add'; ?> App </h2>
    </div>


    <div class="card mb-2">
        <div class="card-body">
            <form id="primary_form" name="primary_form">
                <input type="hidden" value="1" name="add_more_app">
                <input type="hidden" value="<?= $id ?>" name="id">

                <div class="row">

                    <div class="col-md-6">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Name of the game" value="<?= $name; ?>">
                    </div>


                    <div class="col-md-6">
                        <label class="form-label">Thumbnail</label>
                        <input type="text" name="thumb" class="form-control" placeholder="Link" value="<?= $thumb; ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Link</label>
                        <input type="text" name="link" placeholder="Game Link" class="form-control" value="<?= $link; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary"><?php if (isset($id)) echo 'Update';
                                                                    else echo 'Add'; ?> App</button>
            </form>
        </div>
    </div>
    </div>

</section>

<?php
require_once "footer.php";
?>


<script>
    $('#primary_form').submit(function(e) {
        e.preventDefault()

        $.ajax({
            url: 'core/actions.php',
            type: 'POST',
            data: new FormData($('#primary_form')[0]),
            processData: false,
            contentType: false,
        }).done(function(data) {

            swal({
                title: "Done",
                text: data,
                icon: "success",
                button: "Ok",
            }).then(function() {
                // location.reload()
            });

        }).fail(function(data) {
            swal({
                title: "Failed to upload",
                html: data,
                icon: "error",
                button: "Ok",
            })
        });




    })
</script>