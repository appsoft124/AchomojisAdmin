</main>



<script src="js/jquery-3.5.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

<!-- ChartJS files-->
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<!-- Custom JS -->
<script src="js/scriptc619.js?v=1.0" type="text/javascript"></script>

<script> //
	$('.delete').click(function(e) {
		e.preventDefault()
		e.stopPropagation()

		var type = $(this).attr('data-type')
		var id = $(this).attr('data-id')
		if (confirm('Do you want to delete this ' + type + ' whose ID is ' + id + '.')) {
			console.log('deleting... ' + type + ' id=' + id)
			$.post("core/write_actions.php", {
				form_delete: 1,
				type: type,
				id: id
			}, function(data, status) {
				// console.log('Delete result'+data+" status "+status)
				location.reload()
			});

		} else {
			console.log('Delete cancelled ')
		}
	})
	
	

		$('.notif').click(function(e) {
		e.preventDefault()
		e.stopPropagation()

		var type = $(this).attr('data-type')
		var id = $(this).attr('data-id')

		var msg_body = 'In Custom Data use "'+type+'" as key and "'+ id +'" as value to send this '+type+' in a notification from Firebase'
            swal({
                title: "Create Notification",
                text: msg_body,
                icon: "success",
                button: "Ok",
            });

	
	})
	
	

	$('.delete_now').click(function(e) {
		e.preventDefault()
		e.stopPropagation()

		var type = $(this).attr('data-type')
		var id = $(this).attr('data-id')
		console.log('deleting... ' + type + ' id=' + id)
		$.post("core/write_actions.php", {
			form_delete: 1,
			type: type,
			id: id
		}, function(data, status) {
			location.reload()
		});


	})

	$('.edit').click(function(e) {
		e.preventDefault()
		e.stopPropagation()
		var type = $(this).attr('data-type')
		var id = $(this).attr('data-id')
		location.href = 'core/write_actions.php?form_edit=1&type=' + type + '&id=' + id
	})
</script>

<script type="text/javascript">
	if (localStorage.getItem("darkmode")) {
		var body_el = document.body;
		body_el.className += 'dark';
	}


	$(document).ready(function() {
		$("#loader").css("display", "none");
	});
</script>

</body>

<!-- Mirrored from www.ecommerce-admin.com/demo/page-index-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 20 Dec 2021 13:21:29 GMT -->

</html>