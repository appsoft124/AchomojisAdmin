<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// Get categories
//$categories = $db->run('SELECT * FROM categories ORDER BY name ASC');
$categories = $db->run("SELECT * FROM categories WHERE access_type = 'free' ORDER BY name ASC");


$id = $_REQUEST['id'];
if (!empty($id)) {
    $emoji = $db->row('SELECT * FROM free_emojis WHERE id = ?', $id);
    $name = $emoji['name'];
    $des = $emoji['des'];
    $category_id = $emoji['category_id'];
    $image_url = $emoji['image_url'];
}
?>

<section class="content-main" style="max-width: 70%">
    <div class="content-header">
        <h2 class="content-title"><?= isset($id) ? 'Update' : 'Add'; ?> Free Emoji 😊</h2>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form id="emoji_form" name="emoji_form" enctype="multipart/form-data">
                <input type="hidden" name="add_free_emoji" value="1">
                <input type="hidden" name="id" value="<?= $id; ?>">

                <!-- Category Dropdown -->
                <div class="mb-4 row">
                    <div class="col-md-12">
                        <label for="category" class="form-label">🎨 Category</label>
                        <select name="category_id" id="category" class="form-control" required>
                            <option value="">-- Choose Category --</option>
                            <?php foreach ($categories as $cat) { ?>
                                <option value="<?= $cat['id']; ?>" <?= ($cat['id'] == $category_id) ? 'selected' : ''; ?>>
                                    <?= $cat['name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <!-- Name -->
                <div class="mb-4">
                    <label for="name" class="form-label">😄 Emoji Name</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?= $name; ?>" required>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <label for="des" class="form-label">📝 Description</label>
                    <input type="text" name="des" id="des" class="form-control" value="<?= $des; ?>">
                </div>

                <!-- Image Upload -->
                <div class="mb-4">
                    <label for="image" class="form-label">🖼️ Upload Image</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*" <?= empty($image_url) ? 'required' : ''; ?>>
                    <?php if ($image_url): ?>
                        <p><strong>Current Image:</strong> <img src="<?= $image_url; ?>" alt="Emoji Image" width="100"></p>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary"><?= isset($id) ? 'Update' : 'Add'; ?> Emoji 🚀</button>
            </form>
        </div>
    </div>
</section>

<?php require_once "footer.php"; ?>

<script>
    $(document).ready(function () {
        $('#emoji_form').submit(function (e) {
            e.preventDefault();

            // Create FormData object to handle file upload
            var formData = new FormData(this);

            $.ajax({
                url: 'core/actions.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false
            }).done(function (response) {
                swal("Success ✅", response, "success").then(() => {
                    location.reload();
                });
            }).fail(function () {
                swal("Upload Failed ❌", "Something went wrong. Try again.", "error");
            });
        });
    });
</script>
