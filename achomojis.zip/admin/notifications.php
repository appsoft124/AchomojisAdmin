<?php
require_once "../vendor/autoload.php";
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

$factory = (new Factory)->withServiceAccount(__DIR__ . '/../firebase/firebase_service_account.json');
$messaging = $factory->createMessaging();

$imageUrl = '';
$resultMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $body = $_POST['body'] ?? '';

    // ✅ Image Upload Section
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/notification/';
        $fileName = time() . '_' . basename($_FILES['image']['name']);
        $uploadFile = $uploadDir . $fileName;

        // ✅ Create folder if not exists
        if (!file_exists($uploadDir)) {
            if (!mkdir($uploadDir, 0777, true)) {
                $resultMessage = "❌ Failed to create upload folder!";
            }
        }

        // ✅ Move uploaded file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            // ✅ Generate Public Image URL
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
            $domain = $_SERVER['HTTP_HOST'];
            // $imageUrl = $protocol . "://" . $domain . "/uploads/notification/" . $fileName;
            $imageUrl = $protocol . "://" . $domain . "/achomojis/uploads/notification/" . $fileName;

        } else {
            $resultMessage = "❌ Failed to move uploaded file.";
        }
    }

    // ✅ Firebase Notification
    $notification = Notification::create($title, $body);
    if (!empty($imageUrl)) {
        $notification = $notification->withImageUrl($imageUrl);
    }

    $dataPayload = [
        'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
        'title' => $title,
        'body' => $body,
        'image' => $imageUrl,
    ];

    $message = CloudMessage::withTarget('topic', 'all_users')
        ->withNotification($notification)
        ->withData($dataPayload)
        ->withHighestPossiblePriority();

    try {
        $messaging->send($message);
        $resultMessage = "✅ Notification sent successfully!";
    } catch (\Kreait\Firebase\Exception\MessagingException $e) {
        $resultMessage = "❌ Messaging Error: " . $e->getMessage();
    } catch (\Kreait\Firebase\Exception\FirebaseException $e) {
        $resultMessage = "❌ Firebase Error: " . $e->getMessage();
    } catch (Exception $e) {
        $resultMessage = "❌ General Error: " . $e->getMessage();
    }
}
?>

<!-- ✅ HTML Form -->
<section class="content-main" style="max-width: 70%">
    <div class="content-header">
        <h2 class="content-title">Send Firebase Notification</h2>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="mb-4 col-md-12">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" id="title" required>
                </div>

                <div class="mb-4 col-md-12">
                    <label for="body" class="form-label">Message</label>
                    <textarea name="body" class="form-control" id="body" rows="4" required></textarea>
                </div>

                <div class="mb-4 col-md-12">
                    <label for="image" class="form-label">Select Image (Optional)</label>
                    <input type="file" name="image" class="form-control" id="image" accept="image/*">
                    <small class="text-muted">Image will be sent with the notification</small>
                </div>

                <button type="submit" class="btn btn-primary">Send Notification</button>
            </form>

            <?php if (!empty($resultMessage)): ?>
                <div class="alert alert-info mt-4" role="alert">
                    <?php echo $resultMessage; ?>
                    <?php if (!empty($imageUrl)): ?>
                        <br>Image URL: <a href="<?php echo $imageUrl; ?>" target="_blank"><?php echo $imageUrl; ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require_once "footer.php"; ?>
