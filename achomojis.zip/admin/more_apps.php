<?php
require_once "header.php";
$more_apps = $db->run('SELECT * FROM more_apps');
?>

<div class="loader text-center" id="loader">
  <!-- <img src="images/loading.gif" style="width:30%; margin-top:100px"> -->
</div>

<section class="content-main">
  <div class="content-header">
    <h2 class="content-title">More Apps</h2>

    <div>
      <a class="btn text-white btn-success btn-sm" href="add_more_app.php">Add App</a>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">

      <div class="table-responsive">
        <table class="table table-hover" id="myTableSurface">
          <thead>
            <tr>
              <th>ID</th>
              <th>Thumbnail</th>
              <th>Name</th>
              <th>Link</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php foreach ($more_apps as $data) {
            ?>
              <tr class="show" id="<?= $data['id']; ?>">
                <td><?php echo $data['id']; ?></td>
                <td> <img src="<?= $data["thumb"] ?>"> </td>
                <td><?php echo $data['name']; ?></td>
                <td><?php echo $data['link']; ?></td>
                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light"> <span class="material-symbols-rounded">
                        more_horiz
                      </span></i> </a>
                    <div class="dropdown-menu">
                      <a class="dropdown-item edit" data-type="more_app" data-id="<?= $data['id']; ?>">Edit info</a>
                      <button class="dropdown-item text-danger delete" data-type="more_app" data-id="<?= $data['id']; ?>">Delete</button>
                    </div>
                  </div>
                </td>
              </tr>
            <?php } ?>
        </table>
      </div>
    </div>
  </div>

</section>

<?php
require_once "footer.php";
?>
<script>
  $(document).ready(function() {

    $("#loader").css("display", "none");


    $('#language').change(function() {
      var l = $('#language').val()
      location.replace('./ads.php?language=' + l)
    })

    // $('.show').click(function () {
    //     var id  = $(this).attr('id')
    //     location.href= 'movies.php?show_id='+id
    // })

    $('#myTableSurface').DataTable({
      "pageLength": 50
    });

  });
</script>