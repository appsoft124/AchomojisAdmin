<?php
include "../core/db.php";

// get_subcategories.php
require_once "header.php";

// Check if category_id is provided
if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    // Get subcategories for the selected category
    $subcategories = $db->run('SELECT * FROM subcategories WHERE category_id = ? ORDER BY name ASC', [$category_id]);

    // Return the subcategories as JSON
    echo json_encode($subcategories);
} else {
    // If category_id is not provided or empty
    echo json_encode([]);
}
?>
