<?php
session_start();
require_once "../../core/db.php";

if (isset($_POST['signInForm'])) {
    $admin_email = $_POST['admin_email'];
    $admin_password = $_POST['admin_password'];
    $admin_password = md5($_POST['admin_password']);

    if ($admin_email == "" || $admin_password == "") {
        echo "0";
    } else {
        $row = $db->row('SELECT * FROM `admins` WHERE admin_email = ? AND `admin_password` = ?', $admin_email, $admin_password);
        if ($row) {
            $id = $row['id'];
            $_SESSION["admin_id"] = $id;
            echo $id;
        } else {
            echo "0";
        }
    }
}
