<?php

require_once "../../core/db.php";

session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

if (isset($_GET['signout'])) {
    unset($_SESSION['admin_id']);
    session_destroy();
    echo "<script>window.location='../index.php?secure=1'</script>";
    die;
}



// ADD/UPDATE CATEGORY
// ============================
if (isset($_POST['add_category'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $des = $_POST['des'];
    $access_type = $_POST['access_type'];
    $image_url = '';

    // 🌐 Localhost path (change later when live)
    $site_url = 'https://thinkialab.com/achomojis/admin/';

    try {
        // 📤 Upload image if present
        if (!empty($_FILES['image']['name'])) {
            $uploadDir = '../uploads/category/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION); // keep extension
            $filename = time() . '_' . rand(1000, 9999) . '.' . $ext;
            $targetFile = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $image_url = $site_url . 'uploads/category/' . $filename;
            }
        }

        // 🛠 If updating
        if (!empty($id)) {
            $old = $db->row("SELECT * FROM categories WHERE id = ?", $id);
            if (empty($image_url)) {
                $image_url = $old['image_url']; // keep old image
            }

            $db->update('categories', [
                "name" => $name,
                "des" => $des,
                "image_url" => $image_url,
                "access_type" => $access_type
            ], ["id" => $id]);

            echo "Category updated successfully! (ID = $id)";
        } else {
            // ➕ Add new
            $db->insert('categories', [
                "name" => $name,
                "des" => $des,
                "image_url" => $image_url,
                "access_type" => $access_type
            ]);

            $lastId = $db->getPdo()->lastInsertId();
            echo "Category added successfully! (ID = $lastId)";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }

    exit;
}




// ============================
// ADD/UPDATE SUBCATEGORY
// ============================
if (isset($_REQUEST['add_subcategory'])) {
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $des = $_REQUEST['des'];
    $category_id = $_REQUEST['category_id'];
    $image_url = '';

    $site_url = 'https://thinkialab.com/achomojis/admin/';

    try {
        // Handle Image Upload
        if (!empty($_FILES['image']['name'])) {
            $uploadDir = '../uploads/subcategories/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $filename = time() . '_' . basename($_FILES['image']['name']);
            $targetFile = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $image_url = $site_url . 'uploads/subcategories/' . $filename;
            } else {
                throw new Exception("Failed to upload image.");
            }
        }

        // Update or Insert Subcategory
        if (!empty($id)) {
            // Get old image URL if no new image uploaded
            if (empty($image_url)) {
                $old = $db->row("SELECT * FROM subcategories WHERE id = ?", $id);
                $image_url = $old['image_url'];
            }

            $db->update('subcategories', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url
            ], [
                "id" => $id
            ]);

            echo "Subcategory updated successfully! (ID = $id)";
        } else {
            // Insert new subcategory
            $db->insert('subcategories', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url
            ]);

            $lastId = $db->getPdo()->lastInsertId();
            echo "Subcategory added successfully! (ID = $lastId)";
        }
    } catch (\Throwable $th) {
        echo "Error: " . $th->getMessage();
    }

    exit;
}

/*if (isset($_REQUEST['add_subcategory'])) {
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $des = $_REQUEST['des'];
    $category_id = $_REQUEST['category_id'];
    $image_url = '';

 $site_url = 'https://thinkialab.com/achomojis/admin/'; // Corrected site URL

    try {
        // Handle Image Upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            // Set image upload directory
            $uploadDir = '../uploads/subcategories/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            // Generate unique filename
            $filename = time() . '_' . basename($_FILES['image']['name']);
            $targetFile = $uploadDir . $filename;

            // Check if file upload was successful
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                // Set the image URL
              
                $image_url = $site_url . 'uploads/subcategories/' . $filename;
            } else {
                throw new Exception("Failed to upload image.");
            }
        }

        // Update or Insert Subcategory
        if ($id) {
            // Update existing subcategory
            $db->update('subcategories', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url ? $image_url : $_REQUEST['image_url'] 
            ], [
                "id" => $id
            ]);

            echo "Subcategory updated successfully! (ID = $id)";
        } else {
            // Insert new subcategory
            $db->insert('subcategories', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url
            ]);

            $lastId = $db->getPdo()->lastInsertId();
            echo "Subcategory added successfully! (ID = $lastId)";
        }
    } catch (\Throwable $th) {
        echo "Error: " . $th->getMessage();
    }

    exit;
}*/

if (isset($_REQUEST['add_paid_emoji'])) {
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $des = $_REQUEST['des'];
    $category_id = $_REQUEST['category_id'];
    $subcategory_id = $_REQUEST['subcategory_id'];

    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/emojis/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $filename = time() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image_url = 'https://thinkialab.com/achomojis/admin/uploads/emojis/' . $filename;
        } else {
            echo "Error: Failed to upload image."; exit;
        }
    }

    try {
        if ($id) {
            // ✅ Fetch existing record first
            $old = $db->row("SELECT * FROM paid_emojis WHERE id = ?", $id);
            if (empty($image_url)) {
                $image_url = $old['image_url'];
            }

            $db->update('paid_emojis', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "subcategory_id" => $subcategory_id,
                "image_url" => $image_url
            ], [ "id" => $id ]);

            echo "Paid Emoji updated successfully! (ID = $id)";
        } else {
            $db->insert('paid_emojis', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "subcategory_id" => $subcategory_id,
                "image_url" => $image_url
            ]);

            $lastId = $db->getPdo()->lastInsertId();
            echo "Paid Emoji added successfully! (ID = $lastId)";
        }
    } catch (\Throwable $th) {
        echo "Error: " . $th->getMessage();
    }

    exit;
}




// ============================
// ADD/UPDATE FREE EMOJI
// ============================
if (isset($_REQUEST['add_free_emoji'])) {
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $des = $_REQUEST['des'];
    $category_id = $_REQUEST['category_id'];

    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/emojis/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $filename = time() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image_url = 'https://thinkialab.com/achomojis/admin/uploads/emojis/' . $filename;
        } else {
            echo "Error: Failed to upload image."; exit;
        }
    }

    try {
        if ($id) {
            // ✅ Fetch existing record
            $old = $db->row("SELECT * FROM free_emojis WHERE id = ?", $id);
            if (empty($image_url)) {
                $image_url = $old['image_url'];
            }

            $db->update('free_emojis', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url
            ], [ "id" => $id ]);

            echo "Free Emoji updated successfully! (ID = $id)";
        } else {
            $db->insert('free_emojis', [
                "name" => $name,
                "des" => $des,
                "category_id" => $category_id,
                "image_url" => $image_url
            ]);

            $lastId = $db->getPdo()->lastInsertId();
            echo "Free Emoji added successfully! (ID = $lastId)";
        }
    } catch (\Throwable $th) {
        echo "Error: " . $th->getMessage();
    }

    exit;
}






if (isset($_REQUEST['add_more_app'])) {
    $id = $_REQUEST['id'];
    try {
        if ($id) {
            $db->update('more_apps', [
                "name" => '' . $_REQUEST['name'],
                "thumb" => '' . $_REQUEST['thumb'],
                "link" => '' . $_REQUEST['link'],
            ], [
                'id' => $id
            ]);
            echo 'Updated ID = ' . $id . "\n";
        } else {
            $insert_res =   $db->insert('more_apps', [
                "name" => '' . $_REQUEST['name'],
                "thumb" => '' . $_REQUEST['thumb'],
                "link" => '' . $_REQUEST['link'],
            ]);

            $id =   $pdo = $db->getPdo()->lastInsertId();;

            echo 'Inserted ID = ' . $id . "\n";
        }
    } catch (\Throwable $th) {
        //throw $th;
        echo $th;
    }
}



if (isset($_REQUEST['add_admin'])) {
    try {
        $pass =  md5($_REQUEST['pass']);
        $insert_res =   $db->insert('admins', [
            "admin_email" => $_REQUEST['email'],
            "admin_password" => $pass,
        ]);

        $id =   $pdo = $db->getPdo()->lastInsertId();;

        echo 'Admin Added. ID = ' . $id . "\n";
    } catch (\Throwable $th) {
        //throw $th;
        echo $th;
    }
}



if (isset($_REQUEST['change_pass'])) {
    try {
        $pass =  md5($_REQUEST['pass']);


        $db->update('admins', [
            "admin_password" => $pass,
        ], [
            'id' => $_SESSION['admin_id']
        ]);
        
       
        $id =   $pdo = $db->getPdo()->lastInsertId();;

        echo 'Your password is changed. Please Note: '.$_REQUEST['pass'];
    } catch (\Throwable $th) {
        //throw $th;
        echo $th;
    }
}


/*** adding things ***/


// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, "https://myavens18052002.xyz/copyfrommaster.php");
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// $response = curl_exec($ch);
// curl_close($ch);
// echo "\n";
// echo $response;

