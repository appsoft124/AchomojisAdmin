<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}


require_once "../../core/db.php";



// Enable error reporting (for debugging, optional in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Function to record deletions
function recordDeletion($db, $deletedId, $type) {
    $db->insert('deleted_items', [
        'deleted_id' => $deletedId,
        'type' => $type
    ]);
}




// Handle delete request
if (isset($_REQUEST['form_delete'])) {
    $type = $_REQUEST['type'];
    $id = $_REQUEST['id'];

    file_put_contents("delete_log.txt", "Delete triggered for type=" . $type . ", ID=" . $id . "\n", FILE_APPEND);

    try {
        $deleted = false;

        if ($type == 'category') {
          
             $deleted = $db->delete('categories', ['id' => $id]);
            file_put_contents("delete_log.txt", "Category deleted? = " . var_export($deleted, true) . "\n", FILE_APPEND);

        } else if ($type == 'subcategory') {
            // recordDeletion($db, $id, 'subcategory');
            $deleted = $db->delete('subcategories', ['id' => $id]);

        } else if ($type == 'paid_emoji') {
            // recordDeletion($db, $id, 'paid_emoji');
            $deleted = $db->delete('paid_emojis', ['id' => $id]);

        } else if ($type == 'free_emoji') {
            // recordDeletion($db, $id, 'free_emoji');
            $deleted = $db->delete('free_emojis', ['id' => $id]);
        }

        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode([
            'success' => $deleted,
            'message' => $deleted ? 'Item deleted successfully' : 'Failed to delete item'
        ]);
        exit;

    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ]);
        exit;
    }
}



if (isset($_REQUEST['form_edit'])) {
    $type = $_REQUEST['type'];
    $id = $_REQUEST['id'];

    if ($type == 'category') {
    header('Location: ../add_category.php?id=' . $id);
    exit;
}

    if ($type == 'subcategory') {
    header('Location: ../add_subcategory.php?id=' . $id);
    exit;
}


 if ($type == 'free_emoji') {
    header('Location: ../add_free_emojis.php?id=' . $id);
    exit;
}


 if ($type == 'paid_emoji') {
    header('Location: ../add_paid_emojis.php?id=' . $id);
    exit;
}

    
    
    
   
    
    echo 'editing...... ' . $type . ' id=' . $id;
}
