<?php
// if(!empty($_GET['secure'])){
// }else{
//      die;
// }
include "../core/db.php";
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Admin login</title>

    <link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">

    <link href="css/bootstrapf9e3.css?v=1.1" rel="stylesheet" type="text/css" />


    <!-- custom style -->
    <link href="css/uif9e3.css?v=1.1" rel="stylesheet" type="text/css" />
    <link href="css/responsivef9e3.css?v=1.1" rel="stylesheet" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    

</head>

<body>

    <b class="screen-overlay"></b>

    <main>


        <section class="content-main">

            <!-- ============================ COMPONENT LOGIN   ================================= -->
            <div class="card shadow mx-auto" style="max-width: 380px; margin-top:170px;">
                <div class="card-body">
                    <h4 class="card-title mb-4 text-center">Welcome Back! Admin</h4>
                    <form id="signInForm">
                        <input type="hidden" name="signInForm" value="1">
                        <div class="mb-3">
                            <input type="email" name="admin_email" class="form-control" placeholder="Email">
                        </div> <!-- form-group// -->
                        <div class="mb-3">
                            <input type="password" name="admin_password" class="form-control" placeholder="Password">
                        </div> <!-- form-group// -->
                        <div class="g-recaptcha" data-sitekey="6LeAkOgUAAAAACcy3uY6N9H9SJMS27n3Zx2OOnYK" data-action="account_login" data-callback="onSuccess"></div>

                        <div class="mb-3">
                            <label class="form-check">
                                <input type="checkbox" class="form-check-input" checked="">
                                <span class="form-check-label">Remember</span>
                            </label>
                        </div> <!-- form-group form-check .// -->
                        <div class="mb-4">
                            <button type="submit" class="btn btn-primary w-100"> Login </button>
                        </div> <!-- form-group// -->
                    </form>



                </div> <!-- card-body.// -->
            </div> <!-- card .// -->


            <!-- ============================ COMPONENT LOGIN  END.// ================================= -->




        </section> <!-- content-main end// -->
    </main>

    <script>
        if (localStorage.getItem("darkmode")) {
            var body_el = document.body;
            body_el.className += 'dark';
        }
    </script>

    <script src="js/jquery-3.5.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <!-- Custom JS -->
    <script src="js/scriptc619.js?v=1.0"></script>

</body>
<script>
    onSuccess('')

    function onSuccess(token) {
        $('#signInForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                type: 'post',
                url: 'core/login.php',
                data: $('#signInForm').serialize(),
                success: function(val) {
                    console.log(val)
                    if (val == "0" || val == 0) {
                        swal({
                            title: "You Entered Wrong Credentials!",
                            text: "Please Try Again!",
                            icon: "error",
                            button: "Ok",
                        });
                    } else {
                        swal({
                            title: "Login successfully.!",
                            text: "Thank You!",
                            icon: "success",
                            button: "Ok",
                        }).then(function() {
                            location.replace('dashboard.php');
                        });

                        setTimeout(function() {
                            location.replace('dashboard.php');
                        }, 1000);
                    }
                }
            });

        });
    }
</script>
<script src="https://www.google.com/recaptcha/enterprise.js" async defer></script>

</html>