<?php
require_once "header.php";
?>

<section class="content-main">
     <div class="content-header">
          <h2 class="content-title">Admins</h2>
     </div>

     <div class="card" style="margin-bottom:30px !important">
          <div class="card-body">
               <div class="row">


                    <div class="col-md-4">

                         <h5 class="card-title">Add New Admin</h5>


                         <form id="primary_form" name="primary_form">
                              <input type="hidden" value="1" name="add_admin">

                              <div class="mb-4">
                                   <label for="email" class="form-label">Add Email</label>
                                   <input type="text" name="email" placeholder="Type Here" class="form-control" required="" id="email" />
                              </div>
                              <div class="mb-4">
                                   <label class="form-label">Add Password</label>
                                   <input type="text" name="pass" placeholder="Type Here" class="form-control" required="" id="password" />
                              </div>
                              <div class="d-grid">
                                   <input type="submit" value="Add Admin" class="btn btn-primary" name="admin">
                              </div>
                         </form>
                    </div>

                    <div class="col-md-4"></div>

                    <div class="col-md-4">
                         <h5 class="card-title">Change My Password</h5>
                         <form id="secondary_form" name="primary_form">
                              <input type="hidden" value="1" name="change_pass">

                              <div class="mb-4">
                                   <label class="form-label">Type New Password</label>
                                   <input type="text" name="pass" class="form-control" required="" id="password" />
                              </div>
                              <div class="d-grid">
                                   <input type="submit" value="Change Password" class="btn btn-primary" name="admin">
                              </div>
                         </form>
                    </div>


               </div>
          </div>
     </div>



     <div class="card">
          <div class="card-body">
               <div class="row">

                    <div class="col-md-8">
                         <div class="row">
                              <div class="col-md-8">
                                   <h5 class="card-title">All Admins</h5>
                              </div>
                         </div>
                         <br>
                         <div class="table-responsive">
                              <table class="table table-hover">
                                   <thead>
                                        <tr>
                                             <th>ID</th>
                                             <th>Email</th>
                                             <th>Created At</th>
                                             <th class="text-end">Action</th>
                                        </tr>
                                   </thead>
                                   <tbody id="myTable">
                                        <?php foreach ($db->run('select * from admins') as $data) { ?>
                                             <tr>
                                                  <td><?php echo $data['id']; ?></td>
                                                  <td><?php echo $data['admin_email']; ?></td>
                                                  <td><?php echo $data['created_at']; ?></td>
                                                  <td class="text-end">
                                                       <button class="btn btn-danger py-1 delete" data-type="admin" data-id="<?= $data['id']; ?>">Delete</button>
                                                  </td>
                                             </tr>
                                        <?php } ?>
                                   </tbody>
                              </table>

                         </div>
                    </div>

               </div>
          </div>
     </div>
</section>
<?php
require_once "footer.php";
?>

<script>
     $('#primary_form').submit(function(e) {
          e.preventDefault()

          $.ajax({
               url: 'core/actions.php',
               type: 'POST',
               data: new FormData($('#primary_form')[0]),
               processData: false,
               contentType: false,
          }).done(function(data) {

               swal({
                    title: "Done",
                    text: data,
                    icon: "success",
                    button: "Ok",
               }).then(function() {
                    location.reload()
               });

          }).fail(function(data) {
               swal({
                    title: "Failed to upload",
                    html: data,
                    icon: "error",
                    button: "Ok",
               })
          });
     })
     $('#secondary_form').submit(function(e) {
          e.preventDefault()

          $.ajax({
               url: 'core/actions.php',
               type: 'POST',
               data: new FormData($('#secondary_form')[0]),
               processData: false,
               contentType: false,
          }).done(function(data) {
               swal({
                    title: "Done",
                    text: data,
                    icon: "success",
                    button: "Ok",
               }).then(function() {
                    location.reload()
               });

          }).fail(function(data) {
               swal({
                    title: "Failed",
                    html: data,
                    icon: "error",
                    button: "Ok",
               })
          });
     })
</script>