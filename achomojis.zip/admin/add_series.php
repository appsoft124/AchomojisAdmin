<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

$id = $_REQUEST['id'];
if (!empty($id)) {
    $category = $db->row('SELECT * FROM categories WHERE id = ?', $id);
    $name = $category['name'];
    $des = $category['des'];
    $image = $category['image'];
}
?>

<section class="content-main" style="max-width: 70%">
    <div class="content-header">
        <h2 class="content-title"><?php echo isset($id) ? 'Update' : 'Add'; ?> Category</h2>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form id="category_form" name="category_form">
                <input type="hidden" value="1" name="add_category">
                <input type="hidden" value="<?= $id; ?>" name="id">

                <div class="mb-4 col-md-12">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?= $name; ?>">
                </div>

                <div class="mb-4 col-md-12">
                    <label for="des" class="form-label">Description</label>
                    <input type="text" name="des" class="form-control" id="des" value="<?= $des; ?>">
                </div>

                <div class="mb-4 col-md-12">
                    <label for="image" class="form-label">Image URL</label>
                    <input type="text" name="image" class="form-control" id="image" value="<?= $image; ?>">
                </div>

                <button type="submit" class="btn btn-primary"><?php echo isset($id) ? 'Update' : 'Add'; ?> Category</button>
            </form>
        </div>
    </div>
</section>

<?php require_once "footer.php"; ?>

<script>
    $('#category_form').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: 'core/actions.php',
            type: 'POST',
            data: new FormData($('#category_form')[0]),
            processData: false,
            contentType: false
        }).done(function(data) {
            swal({
                title: "Done",
                text: data,
                icon: "success",
                button: "Ok",
            }).then(function() {
                // Optionally reload or redirect
            });
        }).fail(function() {
            swal({
                title: "Failed to upload",
                icon: "error",
                button: "Ok",
            });
        });
    });
</script>
