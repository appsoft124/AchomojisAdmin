<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

$id = $_REQUEST['id'];

if (isset($id)) {
    $movie = $db->row('SELECT * FROM languages WHERE id = ?', $id);
    $name = $movie['name'];
    $audio = $movie['audio'];
     $no = $movie['no'];
}


?>


<section class="content-main" style="max-width: 70%">

    <div class="content-header">
        <h2 class="content-title"><?php if (isset($id)) echo 'Update';
                                    else echo 'Add'; ?> Language </h2>
    </div>


    <div class="card mb-2">
        <div class="card-body">
            <form id="primary_form" name="primary_form">
                <input type="hidden" value="1" name="form_add_language">
                
                <input type="hidden" value="<?= $id ?>" name="id">

                <div class="row">

                    <div class="col-md-6">
                        <label class="form-label">No</label>
                        <input type="text" name="no" class="form-control" value="<?= $no; ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" value="<?= $name; ?>">
                    </div>

                  

                    <div class="col-md-6">
                        <label class="form-label">Audio</label>
                        <input type="text" name="audio" class="form-control" value="<?= $audio; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary"><?php if (isset($id)) echo 'Update';
                                                                    else echo 'Add'; ?> Language</button>
            </form>
        </div>
    </div>
    </div>

</section>

<?php
require_once "footer.php";
?>


<script>
    $('#primary_form').submit(function(e) {
        e.preventDefault()

        $.ajax({
            url: 'core/actions.php',
            type: 'POST',
            data: new FormData($('#primary_form')[0]),
            processData: false,
            contentType: false,
        }).done(function(data) {

            swal({
                title: "Done",
                text: data,
                icon: "success",
                button: "Ok",
            }).then(function() {
                // location.reload()
            });

        }).fail(function(data) {
            swal({
                title: "Failed to upload",
                html: data,
                icon: "error",
                button: "Ok",
            })
        });




    })
</script>