<?php 
require_once "header.php";


$langs = $db->run('SELECT * from languages ORDER BY no ASC');

?>


<div class="loader text-center" id="loader">
  <!-- <img src="images/loading.gif" style="width:30%; margin-top:100px"> -->
</div>

<section class="content-main">

    <div class="content-header">
    <div>
      <h2 class="content-title">Manage Languages</h2>
    </div>
    <div>
      <a class="btn text-white btn-success btn-sm" href="add_language.php">Add Language</a>
    </div>
  </div>
 
  <div class="card mb-4">
    <div class="card-body">

      <div class="table-responsive">
        <table class="table table-hover" id="myTableSurface">
          <thead>
            <tr>
              <th>ID</th>
               <th>No</th>
              <th>Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php foreach ($langs as $data) {
            ?>
              <tr>
                <td><?php echo $data['id']; ?></td>
                 <td><?php echo $data['no']; ?></td>
                <td><?php echo $data['name']; ?></td>
                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light"> <span class="material-symbols-rounded">
                        more_horiz
                      </span></i> </a>
                    <div class="dropdown-menu">
                      <a class="dropdown-item edit" data-type="language" data-id="<?= $data['id']; ?>">Edit Language</a>
                      <button class="dropdown-item text-danger delete" data-type="language" data-id="<?= $data['id']; ?>">Delete</button>
                      
                    </div>
                  </div>
                </td>
              </tr>
            <?php } ?>
        </table>
      </div>
    </div>
  </div>



</section>

<?php
require_once "footer.php";
?>
<script>
  $(document).ready(function() {});
</script>