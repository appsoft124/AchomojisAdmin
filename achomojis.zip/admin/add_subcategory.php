<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// Get all categories for dropdown
$categories = $db->run('SELECT * FROM categories WHERE access_type ="premium" ORDER BY name ASC');

// Check if this is an update operation
$id = $_REQUEST['id'];
if (!empty($id)) {
    $subcategory = $db->row('SELECT * FROM subcategories WHERE id = ?', $id);
    $name = $subcategory['name'];
    $des = $subcategory['des'];
    $category_id = $subcategory['category_id'];
    $image_url = $subcategory['image_url'];
}
?>

<section class="content-main" style="max-width: 70%">
    <div class="content-header">
        <h2 class="content-title"><?= isset($id) ? 'Update' : 'Add'; ?> Subcategory</h2>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form id="subcategory_form" name="subcategory_form" enctype="multipart/form-data">
                <input type="hidden" value="1" name="add_subcategory">
                <input type="hidden" value="<?= $id; ?>" name="id">

                <!-- Category Dropdown and Name -->
                <div class="mb-4 col-md-12 row">
                    <div class="col-md-6">
                        <label for="category" class="form-label">Category</label>
                        <select name="category_id" class="form-control" id="category" required>
                            <option value="">-- Choose Category --</option>
                            <?php foreach ($categories as $category) { ?>
                                <option value="<?= $category['id']; ?>" <?= ($category['id'] == $category_id) ? 'selected' : ''; ?>>
                                    <?= $category['name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="name" class="form-label">Subcategory Name</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?= $name; ?>" required>
                    </div>
                </div>

                <!-- Optional Description -->
                <div class="mb-4 col-md-12">
                    <label for="des" class="form-label">Description</label>
                    <input type="text" name="des" class="form-control" id="des" value="<?= $des; ?>">
                </div>

                <!-- Image Upload -->
                <div class="mb-4 col-md-12">
                    <label for="image_url" class="form-label">Subcategory Image</label>
                    <input type="file" name="image" class="form-control" id="image_url" accept="image/*" <?= empty($id) ? 'required' : ''; ?>>
                    <?php if (!empty($image_url)) { ?>
                        <img src="<?= $image_url; ?>" alt="Current Image" width="100" style="margin-top: 10px;">
                    <?php } ?>
                </div>

                <button type="submit" class="btn btn-primary"><?= isset($id) ? 'Update' : 'Add'; ?> Subcategory</button>
            </form>
        </div>
    </div>
</section>

<?php require_once "footer.php"; ?>

<script>
    $(document).ready(function () {
        $('#subcategory_form').submit(function (e) {
            e.preventDefault();

            const categoryId = $('#category').val();
            if (!categoryId) {
                swal({
                    title: "Validation Error",
                    text: "Please select a category before submitting.",
                    icon: "warning",
                    button: "Ok",
                });
                return;
            }

            $.ajax({
                url: 'core/actions.php',
                type: 'POST',
                data: new FormData(this),
                processData: false,
                contentType: false
            }).done(function (data) {
                swal({
                    title: "Done",
                    text: data,
                    icon: "success",
                    button: "Ok",
                }).then(function () {
                    location.reload();
                });
            }).fail(function () {
                swal({
                    title: "Upload Failed",
                    text: "Something went wrong. Please try again.",
                    icon: "error",
                    button: "Ok",
                });
            });
        });
    });
</script>
