<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// Get all categories
$categories = $db->run('SELECT * FROM categories ORDER BY name ASC');
?>

<div class="loader text-center" id="loader"></div>

<section class="content-main">
  <div class="content-header" style="display: flex; justify-content: space-between; align-items: center;">
    <div>
      <h2 class="content-title">Categories</h2>
    </div>

    <!-- Move button to the right end -->
    <div style="margin-left: auto;">
      <a class="btn text-white btn-success btn-sm" href="add_category.php">Add Category</a>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover" id="myTableSurface">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($categories as $cat) { ?>
              <tr class="category" id="<?= $cat['id']; ?>">
                <td><?= $cat['id']; ?></td>
                <td>
                  <!-- Ensure correct image URL and adjust the size -->
                 
                  <img src="<?= (is_full_url($cat['image_url']) ? $cat['image_url'] : $tbase . $cat['image_url']) ?>" style="height:80px; width:100px; object-fit: cover;">

                </td>
                <td><?= $cat['name']; ?></td>
                <td><?= $cat['des']; ?></td>
                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light">
                      <span class="material-symbols-rounded">more_horiz</span>
                    </a>
                    <div class="dropdown-menu">
                
                      <button class="dropdown-item text-primary edit" data-type="category" data-id="<?= $cat['id']; ?>">Edit</button>

                      <button class="dropdown-item text-danger delete" data-type="category" data-id="<?= $cat['id']; ?>">Delete</button>
                    </div>
                  </div>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<?php require_once "footer.php"; ?>

<?php
require_once "footer.php";
?>

<script>
  $(document).ready(function () {

    $("#loader").css("display", "none");

    // Handle category change event
    $('#category').change(function () {
      var category_id = $('#category').val();
      location.replace('./category.php');
    });

    // Initialize DataTable for the subcategory table
    $('#myTableSurface').DataTable({
      "pageLength": 50,
      "ordering": false 
    });

  });
</script>

