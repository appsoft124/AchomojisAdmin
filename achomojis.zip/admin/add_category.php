<?php
require_once "header.php";
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// Get category if editing
$id = $_REQUEST['id'];
$name = $des = $image = $access_type = '';

if (!empty($id)) {
    $category = $db->row('SELECT * FROM categories WHERE id = ?', $id);
    $name = $category['name'];
    $des = $category['des'];
    $image = $category['image_url'];
    $access_type = $category['access_type'];
}
?>

<section class="content-main" style="max-width: 70%">
    <div class="content-header">
        <h2 class="content-title"><?= isset($id) ? 'Update' : 'Add'; ?> Category</h2>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form id="category_form" name="category_form" enctype="multipart/form-data">
                <input type="hidden" name="add_category" value="1">
                <input type="hidden" name="id" value="<?= $id; ?>">

                <div class="mb-4 col-md-12">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?= $name; ?>" required>
                </div>

                <div class="mb-4 col-md-12">
                    <label for="des" class="form-label">Description</label>
                    <input type="text" name="des" class="form-control" id="des" value="<?= $des; ?>">
                </div>

                <div class="mb-4 col-md-12">
                    <label for="image" class="form-label">Image</label>
                    <!--<input type="file" name="image" class="form-control" id="image" accept="image/*">-->
                    <input type="file" name="image" class="form-control" id="image" accept="image/*" <?= empty($id) ? 'required' : ''; ?>>

                    <?php if (!empty($image)) { ?>
                        <img src="<?= $image; ?>" style="height: 100px; margin-top: 10px;">
                    <?php } ?>
                </div>

                <div class="mb-4 col-md-12">
                    <label for="access_type" class="form-label">Access Type</label>
                    <select name="access_type" id="access_type" class="form-control" required>
                        <option value="free" <?= ($access_type == 'free') ? 'selected' : '' ?>>Free</option>
                        <option value="premium" <?= ($access_type == 'premium') ? 'selected' : '' ?>>Premium</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary"><?= isset($id) ? 'Update' : 'Add'; ?> Category</button>
            </form>
        </div>
    </div>
</section>

<?php require_once "footer.php"; ?>

<!-- jQuery Ajax Submit -->
<script>
    $('#category_form').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: 'core/actions.php',
            type: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false
        }).done(function(response) {
            swal({
                title: "Success",
                text: response,
                icon: "success",
                button: "OK"
            }).then(() => {
                window.location.reload(); // Or redirect if needed
            });
        }).fail(function() {
            swal({
                title: "Error",
                text: "Something went wrong!",
                icon: "error",
                button: "OK"
            });
        });
    });
</script>
