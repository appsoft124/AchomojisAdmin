<?php
require_once "header.php";

// Fetch all subcategories
$subcategories = $db->run('SELECT * FROM subcategories ORDER BY name ASC');

// Get selected subcategory
$subcategory_id = $_GET['subcategory'] ?? $subcategories[0]['id'];

// Fetch paid emojis sorted alphabetically
// $emojis = $db->run('SELECT * FROM paid_emojis WHERE subcategory_id = ? ORDER BY name ASC', $subcategory_id);


    $emojis = $db->run('SELECT * FROM paid_emojis ORDER BY name ASC');

?>

<div class="loader text-center" id="loader"></div>

<section class="content-main">
  <div class="content-header">
    <div>
      <h2 class="content-title">Paid Emojis</h2>
    </div>

    <div>
      

      <a class="btn text-white btn-success btn-sm" href="add_paid_emojis.php">Add Paid Emoji</a>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover" id="myTableSurface">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Subcategory</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php foreach ($emojis as $emoji) {
              $subcategory = $db->row('SELECT name FROM subcategories WHERE id = ?', $emoji['subcategory_id']);
            ?>
              <tr class="emoji" id="<?= $emoji['id']; ?>">
                <td><?= $emoji['id']; ?></td>
                <td><img src="<?= (is_full_url($emoji['image_url']) ? $emoji['image_url'] : $tbase . $emoji['image_url']) ?>" style="height:80px; width:100px; object-fit: cover;"></td>
                <td><?= $emoji['name']; ?></td>
                <td><?= $subcategory['name']; ?></td>
                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light">
                      <span class="material-symbols-rounded">more_horiz</span>
                    </a>
                    <div class="dropdown-menu">
                      <button class="dropdown-item text-primary edit" data-type="paid_emoji" data-id="<?= $emoji['id']; ?>">Edit</button>
                      <button class="dropdown-item text-danger delete" data-type="paid_emoji" data-id="<?= $emoji['id']; ?>">Delete</button>
                    </div>
                  </div>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<?php require_once "footer.php"; ?>

<script>
  $(document).ready(function () {
    $("#loader").css("display", "none");

    $('#subcategory').change(function () {
      let subcat = $(this).val();
      window.location.href = "paid_emojis.php?subcategory=" + subcat;
    });

    $('#myTableSurface').DataTable({
      "pageLength": 50,
      "ordering": false 
    });
  });
</script>
