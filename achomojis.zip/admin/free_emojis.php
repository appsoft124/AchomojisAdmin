<?php
require_once "header.php";

// Fetch all categories (for mapping category_id to name)
$categories = $db->run('SELECT * FROM categories ORDER BY name ASC');

// Convert categories to array with id => name for faster lookup
$categoryMap = [];
foreach ($categories as $cat) {
  $categoryMap[$cat['id']] = $cat['name'];
}

// Fetch all emojis ordered A-Z by name
$emojis = $db->run('SELECT * FROM free_emojis ORDER BY name ASC');
?>

<div class="loader text-center" id="loader"></div>

<section class="content-main">
  <div class="content-header">
    <div>
      <h2 class="content-title">Free Emojis</h2>
    </div>

    <div>
      <a class="btn text-white btn-success btn-sm" href="add_free_emojis.php">Add Free Emoji</a>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover" id="myTableFree">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <?php foreach ($emojis as $emoji): ?>
              <tr class="emoji" id="<?= $emoji['id']; ?>">
                <td><?= $emoji['id']; ?></td>

                <td>
                  <img src="<?= is_full_url($emoji['image_url']) ? $emoji['image_url'] : $tbase . $emoji['image_url']; ?>" style="height:80px; width:100px; object-fit: cover;">
                </td>

                <td><?= htmlspecialchars($emoji['name']); ?></td>

                <td><?= isset($categoryMap[$emoji['category_id']]) ? htmlspecialchars($categoryMap[$emoji['category_id']]) : 'Unknown'; ?></td>

                <td>
                  <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="btn btn-light">
                      <span class="material-symbols-rounded">more_horiz</span>
                    </a>
                    <div class="dropdown-menu">
                      <button class="dropdown-item text-primary edit" data-type="free_emoji" data-id="<?= $emoji['id']; ?>">Edit</button>
                      <button class="dropdown-item text-danger delete" data-type="free_emoji" data-id="<?= $emoji['id']; ?>">Delete</button>
                    </div>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<?php require_once "footer.php"; ?>

<script>
  $(document).ready(function () {
    $("#loader").css("display", "none");

    $('#myTableFree').DataTable({
      "pageLength": 50,
      "ordering": false 
    });
  });
</script>
