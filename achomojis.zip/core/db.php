<?php

$path = $_SERVER['DOCUMENT_ROOT'];
//$path .= "/vendor/autoload.php";
$path = __DIR__ . "/../vendor/autoload.php"; 
require $path;

//error_reporting(E_ALL ^ E_WARNING);

//$db = \ParagonIE\EasyDB\Factory::fromArray([
//    'mysql:host=localhost;dbname=vionapp_creative_commons',
//    'vionapp',
 //   'bvCcT+Cc%&!Z' 
//]);

// Database connection using EasyDB
// $db = \ParagonIE\EasyDB\Factory::fromArray([
//     'mysql:host=127.0.0.1;dbname=achomojis', // Use '127.0.0.1' for XAMPP
//     'root',  // Default XAMPP username
//     '',      // Default XAMPP password is empty
// ]);


$db = \ParagonIE\EasyDB\Factory::fromArray([
    'mysql:host=127.0.0.1;dbname=u329651745_achomojis',  // Use '127.0.0.1' for local XAMPP or actual host address if live
    'u329651745_achomojis',  // Database username
    'Achomojis123!@#',       // Database password
]);





$pdo = $db->getPdo();


$no_placeholder  = "Number in the list";

function is_full_url($item)
{
    if (str_contains($item, 'https://') || str_contains($item, 'http://')) {
        return true;
    } else {
        return false;
    }
}
function zero_if_null($item)
{
    if ($item == '' || $item == null) {
        return '0';
    } else {
        return $item;
    }
}

// $shows = $db->run('select * from shows');
// echo json_encode($shows);