<?php

include '../core/db.php';
header('Content-Type: application/json');

try {
    // Check if 'category_id' is passed in the URL
    if (!isset($_GET['category_id']) || empty($_GET['category_id'])) {
        http_response_code(400); // Bad Request
        echo json_encode([
            'status' => false,
            'message' => 'Missing category_id parameter',
        ]);
        exit;
    }

    // Safe cast of category_id to int
    $category_id = (int)$_GET['category_id'];

    // Fetch emojis from 'free_emojis' table using category_id
    // $emojiQuery = "SELECT id, name, image_url, category_id FROM free_emojis WHERE category_id = ? ORDER BY id DESC";
        $emojiQuery = "SELECT id, name, image_url, category_id, des FROM free_emojis WHERE category_id = ? ORDER BY name ASC";

    $emojis = $db->safeQuery($emojiQuery, [$category_id]);

    if (empty($emojis)) {
        http_response_code(200); // OK, no data found
        echo json_encode([
            'status' => false,
            'message' => 'No emojis found for the given category_id',
        ]);
        exit;
    }

    // Fetch tray_icon_url from categories table
    $categoryQuery = "SELECT image_url FROM categories WHERE id = ?";
    $category = $db->safeQuery($categoryQuery, [$category_id]);

    // Get tray_icon_url for the category (if it exists)
    $tray_icon_url = isset($category[0]['image_url']) ? $category[0]['image_url'] : null;

    // Prepare emojis with tray_icon_url and only required fields
    $emojis_with_tray_icon = array_map(function($emoji) use ($tray_icon_url) {
        return [
            'id' => $emoji['id'],
            'name' => $emoji['name'],
            'image_url' => $emoji['image_url'],
            'des' => $emoji['des'], // 👈 added

            'tray_icon_url' => $tray_icon_url, // Include tray_icon_url
        ];
    }, $emojis);

    // Final response with emojis
    http_response_code(200); // OK response
    echo json_encode([
        'status' => true,
        'message' => 'Emojis fetched successfully',
        'data' => $emojis_with_tray_icon,
    ]);

} catch (Exception $e) {
    // Log any errors
    error_log("Error fetching emojis: " . $e->getMessage());

    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => false,
        'message' => 'An error occurred while fetching emojis',
        'error' => $e->getMessage(),
    ]);
}
?>
