<?php

include '../core/db.php';
header('Content-Type: application/json');

try {
    // Get access_type from request (GET or POST)
    $access_type = $_GET['access_type'] ?? $_POST['access_type'] ?? null;

    // Validate access_type
    if (!$access_type || !in_array($access_type, ['free', 'premium'])) {
        http_response_code(400); // Bad Request
        echo json_encode([
            'status' => false,
            'message' => 'Invalid or missing access_type. Allowed values: free, premium',
            'data' => []
        ]);
        exit;
    }

    // Use safeQuery instead of run
    $query = "SELECT * FROM categories WHERE access_type = ? ORDER BY name ASC";
    $categories = $db->safeQuery($query, [$access_type]);

   if (!$categories || count($categories) === 0) {
    http_response_code(200); // ✅
    echo json_encode([
        'status' => true,
        'message' => 'No categories found for type: ' . $access_type,
        'data' => [] // Still return data as an empty list
    ]);
    exit;
}


    // Success
    http_response_code(200);
    echo json_encode([
        'status' => true,
        'message' => 'Categories fetched successfully',
        'data' => $categories
    ]);

} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => false,
        'message' => 'An error occurred while fetching categories',
        'error' => $e->getMessage()
    ]);
}
