<?php

include '../core/db.php';
header('Content-Type: application/json');

try {
    // Check if 'subcategory_id' is passed in the URL
    if (!isset($_GET['subcategory_id']) || empty($_GET['subcategory_id'])) {
        http_response_code(400); // Bad Request
        echo json_encode([
            'status' => false,
            'message' => 'Missing subcategory_id parameter',
        ]);
        exit;
    }

    // Cast subcategory_id to integer for safety
    $subcategory_id = (int)$_GET['subcategory_id']; 

    // Fetch emojis from 'paid_emojis' table using subcategory_id
    $emojiQuery = "SELECT id, name, image_url, subcategory_id , des FROM paid_emojis WHERE subcategory_id = ? ORDER BY name ASC";
    $emojis = $db->safeQuery($emojiQuery, [$subcategory_id]);

    if (empty($emojis)) {
        // If no emojis are found for the given subcategory_id
        http_response_code(200); // OK response, but no data found
        echo json_encode([
            'status' => false,
            'message' => 'No emojis found for the given subcategory_id',
        ]);
        exit;
    }

    // Fetch tray_icon_url from subcategories table using subcategory_id
    $subcategoryQuery = "SELECT image_url FROM subcategories WHERE id = ?";
    $subcategory = $db->safeQuery($subcategoryQuery, [$subcategory_id]);

    // If the subcategory image_url exists, use it; otherwise, set tray_icon_url to null
    $tray_icon_url = isset($subcategory[0]['image_url']) ? $subcategory[0]['image_url'] : null;

    // Prepare emojis with tray_icon_url and exclude unnecessary fields
    $emojis_with_tray_icon = array_map(function($emoji) use ($tray_icon_url) {
        return [
            'id' => $emoji['id'],
            'name' => $emoji['name'],
            'image_url' => $emoji['image_url'],
            'des' => $emoji['des'],
            'tray_icon_url' => $tray_icon_url,
        ];
    }, $emojis);

    // Final response with emojis and tray_icon_url
    http_response_code(200); // OK response
    echo json_encode([
        'status' => true,
        'message' => 'Emojis fetched successfully',
        'data' => $emojis_with_tray_icon,
    ]);

} catch (Exception $e) {
    // Log any errors
    error_log("Error fetching emojis: " . $e->getMessage());

    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => false,
        'message' => 'An error occurred while fetching emojis',
        'error' => $e->getMessage(),
    ]);
}
?>
