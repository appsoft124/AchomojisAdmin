<?php

include '../core/db.php';
header('Content-Type: application/json');

try {
    // Get the category_id from the query string
    if (!isset($_GET['category_id']) || empty($_GET['category_id'])) {
        http_response_code(400); // Bad Request
        echo json_encode([
            'status' => false,
            'message' => 'Missing category_id parameter',
        ]);
        exit;
    }

    $category_id = $_GET['category_id'];

    // Fetch subcategories for the provided category_id using safeQuery
    $query = "SELECT * FROM subcategories WHERE category_id = ? ORDER BY name ASC";
    
    // Use safeQuery() method to execute the query
    $subcategories = $db->safeQuery($query, [$category_id]);


    if (empty($subcategories)) {
       
http_response_code(200); // ✅
echo json_encode([
            'status' => false,
            'message' => 'No subcategories found for the given category_id',
        ]);
        exit;
    }

    // Return the subcategories data
    http_response_code(200); // OK
    echo json_encode([
        'status' => true,
        'message' => 'Subcategories fetched successfully',
        'data' => $subcategories,
    ]);

} catch (Exception $e) {
    // Log the error message for debugging
    error_log("Error fetching subcategories: " . $e->getMessage());
    
    // Return a JSON error response
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => false,
        'message' => 'An error occurred while fetching subcategories',
        'error' => $e->getMessage(),
    ]);
}
?>
